"""
RISCV cpu emulator

Author: 
Date:
"""

import argparse
import itertools

# elf file loading
from elfloader import load_elf

# load the isa decoder
from isa import decode_instruction

# load the gates used
from basicgates import gate
from mux import mux

class Plus4(gate):
    "adds four to the input"
    def __init__(self, a):
        self.a = a
        
    def output(self):
        return self.a() + 4

class PC(gate):
    "on the clock, the PC is updated to the next PC"
    def __init__(self, nextpc, initialpc = 0):
        self.nextpc = nextpc
        self.currentpc = initialpc
    def output(self):
        return self.currentpc
    def clock(self):
        self.currentpc = self.nextpc()

class RvCPU():
    "RISCV CPU emulator, memory is an ELFMemory instance (see load_elf)"
    def __init__(self, mem, pc = 0x80000000, quiet = False):
        # store the ELF memory in the cpu instance
        self.mem = mem
        
        # --------------------
        # construct the CPU architecture here (sodor 1 stage)
        # all CPU logic should appear here.
        # --------------------

        # simple fetch/execute cycle does not branch or jump (need muxes!)
        self.pc_plus4 = Plus4(lambda: self.pc.output())
        # this loops the PC back to the input through the plus4 gate
        self.pc = PC(self.pc_plus4.output, initialpc=pc)

        # --------------------
        # end CPU architecture
        # --------------------

        # registers
        self.reg = [0] * 32

        # instruction register (current executing instruction machine code value)
        self.ir = 0

        # misc options
        self.quiet = quiet


    def exec(self):
        """
        fetch from PC and execute the instruction.
        yields the cycle number of the instruction.
        """

        for cycle in itertools.count():
            #if not self.quiet:
                #print(f"Cycle {cycle:8d}: PC={self.pc.output():08x}, FETCH")

            # fetch the instruction from memory
            self.ir = self.mem[self.pc.output()]        
            
            # decode the instruction
            self.instruction = decode_instruction(self.ir, self.pc.output(), symbols)

            # check if we hit a null instruction (end of program)
            if self.instruction.val == 0:
                return
            else:
                # yield the current instruction
                yield cycle

            # clock the CPU, this is the only clocked component in the one-stage CPU
            self.pc.clock()


if __name__=="__main__":
    parser = argparse.ArgumentParser(
        description=__doc__)
    parser.add_argument('elffiles', nargs="+", 
        help="Binary instructions in ELF file format compiled for direct execution on the CPU.")
    parser.add_argument('--wordsize', type=int, default=4)
    parser.add_argument("-q", "--quiet", 
        help="Quieter output (no extra info) [default=True]",
        action="store_true", default=False)    
    
    args = parser.parse_args()

    # allow multiple files from the CLI
    for elffile in args.elffiles:

        print('='*30 + f'<{elffile.center(20)}>' + '='*30)

        try:
            # load the elf file and symbol table into memory 
            sys_mem, symbols = load_elf(elffile, quiet = False)
        except Exception as x:
            print(f"ERR - couldn't load {elffile}.")
            raise(x)        
        
        
        cpu = RvCPU(sys_mem, pc=symbols['_start'], quiet = args.quiet)
        for cycle in cpu.exec():
            if not args.quiet:
                print (f"{cycle:8d}: PC={cpu.pc.output():08x}, IR={cpu.ir:08x}, {cpu.instruction}")

        