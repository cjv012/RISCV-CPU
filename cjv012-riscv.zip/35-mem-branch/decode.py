"""
Decode RISCV machine instructions to assembly code.

Author: 
Date:
"""

import argparse
from typing import Any
from util import readmemhi

class Instruction:
	def __init__(self, val: int):
		self.val = val

		# hints...
		#self.op = 
		#self.rd =
		#self.rs1 =
		#self.rs2 =
		#self.i_imm =
		#self.u_imm =
		# maybe you add other things like instruction type, name, etc.
	def __str__(self) -> str:
		# stub... replace with your code
		# given the decoded fields, format the instruction as a string
		return hex(self.val)

def riscv_decode(instr):
	"""
	Decode a single RISCV machine instruction (as a 32-bit unsigned integer)
	to an assembly code string.	
	"""
	# TODO implement this function for all R, I, and U type instructions.
	# Hint: you might consider creating an Instruction class to decode all 
	# the fields of the instruction. Then add a __str__ method to the class
	# to print the assembly code. (this will be most useful in the future...)
	return str(Instruction(instr))

if __name__=="__main__":
	parser = argparse.ArgumentParser(
        description=__doc__)
	parser.add_argument('hexfile', 
        help="Binary instructions in Verilog HEX format.")
	parser.add_argument('--wordsize', type=int, default=4)
	args = parser.parse_args()

	for addr, instr in readmemhi(args.hexfile, word_size=args.wordsize):
		print(f"PC: {addr:08x}, IR:{instr:08x}, {riscv_decode(instr)}")