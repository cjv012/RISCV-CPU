from basicgates import *

class mux(gate):
	"""
	A Multiplexer takes N inputs and conditionally selects
	one of them as the output. The selection is based on
	the value of the select input. 

	This is similar to an IF statement in a programming language.	

	The first argument is the select input, the remaining arguments
	are the inputs to the mux.  

	"""
	def __init__(self, *args):
		self.sel = args[0]
		self.args = args[1:]
	def output(self):		
		return self.args[self.sel()]()

class testbench:
	def run():
		a = None
		b = None
		sel = None

		# create an instance of the unit under test
		# note that we're passing in functions that return the current
		# values of the inputs
		uut = mux(lambda: sel, lambda: a, lambda: b)
		def display():
			print(", ".join(map(str, [a,b,sel,uut.output()])))
		
		a = "a"
		b = "b"
		sel = 0
		display()		# 0, 1, 0, 0
		sel = 1
		display()		# 0, 1, 1, 1

if __name__ == "__main__":
	testbench.run()
