from enum import Enum

# generated from 'https://raw.githubusercontent.com/ucb-bar/riscv-sodor/master/src/main/scala/rv32_1stage/cpath.scala')
# 2021 - Marchiori

# these enums list more human readable names for the control signals
class val_inst(Enum):
    N = 0
    Y = 1
class pc_sel(Enum):
    PC_PC4 = 0
    PC_JALR = 1
    PC_BRANCH = 2
    PC_JUMP = 3    
class br_type(Enum):
    BR_N = 0
    BR_JR = 1
    BR_GEU = 2
    BR_LT = 3
    BR_NE = 4
    BR_GE = 5
    BR_J = 6
    BR_LTU = 7
    BR_EQ = 8
class op1_sel(Enum):
    OP1_X = 0
    OP1_RS1 = 0
    OP1_IMZ = 1
    OP1_IMU = 2
class op2_sel(Enum):
    OP2_X = 0
    OP2_RS2 = 0
    OP2_IMI = 1
    OP2_IMS = 2
    OP2_PC = 3
class ALU_fun(Enum):
    ALU_X = 0
    ALU_XOR = 1
    ALU_COPY1 = 2
    ALU_SLTU = 3
    ALU_AND = 4
    ALU_ADD = 5
    ALU_SLT = 6
    ALU_SRA = 7
    ALU_SUB = 8
    ALU_SRL = 9
    ALU_SLL = 10
    ALU_OR = 11
class wb_sel(Enum):
    WB_X = 0
    WB_PC4 = 0
    WB_ALU = 1
    WB_MEM = 2
    WB_CSR = 3
class rf_wen(Enum):
    REN_0 = 0
    REN_1 = 1
class mem_em(Enum):
    MEN_0 = 0
    MEN_1 = 1
class mem_wr(Enum):
    M_X = 0
    M_XRD = 0
    M_XWR = 1
class mask_type(Enum):
    MT_B = 1
    MT_BU = 1
    MT_H = 2
    MT_HU = 2
    MT_X = 4
    MT_W = 4
class csr_cmd(Enum):
    CSRC = 0
    CSRW = 1
    CSRI = 2
    CSRN = 3
    CSRS = 4

# control table of all control signals for all supported instructions
# the values correspond to the enum values above.
# use Enum.value to compare to the values in the table
control = {
'add' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 5,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'addi' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 5,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'and' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 4,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'andi' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 4,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'auipc' : {'val_inst': 1,'br_type': 0,'op1_sel': 2,'op2_sel': 3,'ALU_fun': 5,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'beq' : {'val_inst': 1,'br_type': 8,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 2,},
'bge' : {'val_inst': 1,'br_type': 5,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 2,},
'bgeu' : {'val_inst': 1,'br_type': 2,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 2,},
'blt' : {'val_inst': 1,'br_type': 3,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 2,},
'bltu' : {'val_inst': 1,'br_type': 7,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 2,},
'bne' : {'val_inst': 1,'br_type': 4,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 2,},
'csrrc' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 2,'wb_sel': 3,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 0,'pc_sel': 0,},
'csrrci' : {'val_inst': 1,'br_type': 0,'op1_sel': 1,'op2_sel': 0,'ALU_fun': 2,'wb_sel': 3,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 0,'pc_sel': 0,},
'csrrs' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 2,'wb_sel': 3,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 4,'pc_sel': 0,},
'csrrsi' : {'val_inst': 1,'br_type': 0,'op1_sel': 1,'op2_sel': 0,'ALU_fun': 2,'wb_sel': 3,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 4,'pc_sel': 0,},
'csrrw' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 2,'wb_sel': 3,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 1,'pc_sel': 0,},
'csrrwi' : {'val_inst': 1,'br_type': 0,'op1_sel': 1,'op2_sel': 0,'ALU_fun': 2,'wb_sel': 3,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 1,'pc_sel': 0,},
'dret' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 2,'pc_sel': 0,},
'ebreak' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 2,'pc_sel': 0,},
'ecall' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 2,'pc_sel': 0,},
'fence' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'fence_i' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'jal' : {'val_inst': 1,'br_type': 6,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 3,},
'jalr' : {'val_inst': 1,'br_type': 1,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 1,},
'lb' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 5,'wb_sel': 2,'rf_wen': 1,'mem_em': 1,'mem_wr': 0,'mask_type': 1,'csr_cmd': 3,'pc_sel': 0,},
'lbu' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 5,'wb_sel': 2,'rf_wen': 1,'mem_em': 1,'mem_wr': 0,'mask_type': 1,'csr_cmd': 3,'pc_sel': 0,},
'lh' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 5,'wb_sel': 2,'rf_wen': 1,'mem_em': 1,'mem_wr': 0,'mask_type': 2,'csr_cmd': 3,'pc_sel': 0,},
'lhu' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 5,'wb_sel': 2,'rf_wen': 1,'mem_em': 1,'mem_wr': 0,'mask_type': 2,'csr_cmd': 3,'pc_sel': 0,},
'lui' : {'val_inst': 1,'br_type': 0,'op1_sel': 2,'op2_sel': 0,'ALU_fun': 2,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'lw' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 5,'wb_sel': 2,'rf_wen': 1,'mem_em': 1,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'mret' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 2,'pc_sel': 0,},
'or' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 11,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'ori' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 11,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'sb' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 2,'ALU_fun': 5,'wb_sel': 0,'rf_wen': 0,'mem_em': 1,'mem_wr': 1,'mask_type': 1,'csr_cmd': 3,'pc_sel': 0,},
'sh' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 2,'ALU_fun': 5,'wb_sel': 0,'rf_wen': 0,'mem_em': 1,'mem_wr': 1,'mask_type': 2,'csr_cmd': 3,'pc_sel': 0,},
'sll' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 10,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'slli' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 10,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'slt' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 6,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'slti' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 6,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'sltiu' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 3,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'sltu' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 3,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'sra' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 7,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'srai' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 7,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'srl' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 9,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'srli' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 9,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'sub' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 8,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'sw' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 2,'ALU_fun': 5,'wb_sel': 0,'rf_wen': 0,'mem_em': 1,'mem_wr': 1,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'wfi' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 0,'wb_sel': 0,'rf_wen': 0,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'xor' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 0,'ALU_fun': 1,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,},
'xori' : {'val_inst': 1,'br_type': 0,'op1_sel': 0,'op2_sel': 1,'ALU_fun': 1,'wb_sel': 1,'rf_wen': 1,'mem_em': 0,'mem_wr': 0,'mask_type': 4,'csr_cmd': 3,'pc_sel': 0,}
}