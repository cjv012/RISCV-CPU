"""
RISCV Utility functions.

Author: A. Marchiori
Date: 2021+
"""
class BadInstruction(Exception):
    pass

def readmemhi(filename, begin_addr = 0, word_size = 4, byteorder = 'big'):
    "reads a verilog hex file and returns an iterator of word_size integers"
    at = begin_addr
    data = None
    with open (filename, 'r') as f:
        for statement in f.read().split():            
            if statement[0] == '@':
                if data != None:
                    # output segment before creating a new one
                    # multi segment hex files are not supported atm.
                    raise NotImplementedError()
                # the hex file is indexed by words
                at = word_size * int (statement[1:], base=16)
                data = []
            else:
                yield at, int(statement, 16)
                at += word_size
    
def regNumToName(num):
    if type(num) != int or num < 0 or num > 31:
        raise BadInstruction()
    return ['x0','ra','sp','gp',  # 0..3
            'tp', 't0', 't1', 't2', # 4..7
            's0', 's1', 'a0', 'a1', # 8..11
            'a2', 'a3', 'a4', 'a5', # 12..15
            'a6', 'a7', 's2', 's3', # 16..19
            's4', 's5', 's6', 's7', # 20..23
            's8', 's9', 's10', 's11', # 24..27]
            't3', 't4', 't5', 't6'][num] # 28..31