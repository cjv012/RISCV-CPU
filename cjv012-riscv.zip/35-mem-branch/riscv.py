"""
RISCV cpu emulator

This is the sodor-1 stage CPU.

Riscv_simple will run:
- programs/fetch_test
- programs/simple

This is the full CPU which, when complete, can also execute:
- branch instructions
- jump instructions
- loads/stores
- CSR instructions
- syscalls / ecall

Author:  Connor Vucovich
Date: Fall 2023
"""

import argparse
import itertools

# elf file loading
from elfloader import load_elf

# load the isa decoder
from isa import decode_instruction

# this gives us control and the enums for the control signals
from sodor_control import *

# this gives us the CSR memory
from csrs import CsrMemory

# load the gates used
from basicgates import gate
from mux import mux

# utility functions
from util import regNumToName
from twoscomp import int_to_tc, tc_to_int

def fmtreg(x):
    "format a register value for printing"
    return f"{x:08x}" if x != None else "*"*8

class DataMemory(gate):
    "Data Memory gate which implements the risc-v sodor memory interface"
    def __init__(self, segment, addr, byte_count, write_enable, write_val, signed, **kwargs):
        "initialize with the elfmemory segment as mem"
        super().__init__(**kwargs)
        self.mem = segment
        self.addr = addr
        self.byte_count = byte_count
        self.write_enable = write_enable
        self.write_val = write_val
        self.signed = signed

    def output(self):
        "read access"
        addr = self.addr()
        byte_count = self.byte_count()
        signed = self.signed()

        if byte_count == 1:
            v = self.mem[addr] & 0xff
        elif byte_count == 2:
            v = self.mem[addr] & 0xffff
        elif byte_count == 4:
            v = self.mem[addr] & 0xffffffff
        elif byte_count == 8:
            v = self.mem[addr] & 0xffffffffffffffff
        else:
            raise ValueError("Mem can only access Bytes/Half Words/Words.")

        if signed:
            # if signed convert to a signed integer
            v = tc_to_int(v, byte_count*8)

        if not self.quiet:
            print(f"MEM read@{addr:08x} val={v:08x} [{byte_count}]")

        # this extends to 32 bits whether signed or not
        return int_to_tc(v)

    def clock(self):
        "synchronous write"
        if self.write_enable():
            addr = self.addr()
            data = self.write_val()
            byte_count = self.byte_count()

            # mask out any upper bits so to_bytes doesn't complain
            mask = (2**(byte_count*8))-1
            val = (mask & data).to_bytes(length=byte_count,
                byteorder = self.mem.byteorder, signed = False)

            if not self.quiet:
                print(f"MEM write@{addr:08x} val={mask & data:08x} [{byte_count}]")

            self.mem[addr] = val

class Plus4(gate):
    "adds four to the input"
    def __init__(self, a):
        super().__init__()
        self.a = a

    def output(self):
        return self.a() + 4

class PC(gate):
    "on the clock, the PC is updated to the next PC"
    def __init__(self, nextpc, initialpc = 0):
        super().__init__()
        self.nextpc = nextpc
        self.currentpc = initialpc
    def output(self):
        return self.currentpc
    def clock(self):
        self.currentpc = self.nextpc()

class RegFile(gate):
    "RISCV register file"
    def __init__(self, en, wa, wd, **kwargs):
        "en = enable, wa = write address, wd = write data"
        super().__init__(**kwargs)

        # registers
        self.reg = [None] * 32
        # the zero register is always zero
        self.reg[0] = 0

        self.en = en
        self.wa = wa
        self.wd = wd

    def __getitem__(self, idx):
        return self.reg[idx]

    def __setitem__(self, idx, value):
        # don't allow writing to the zero register
        raise ValueError("Use clock() to write to the register file")

    def clock(self):
        "enable, write address, write data"
        if self.en() and self.wa() != 0:
            try:
                if not self.quiet:
                    if self.wd() is None:
                        print(f"REG WRITE reg[{regNumToName(self.wa())}] = None")
                    else:
                        print(f"REG WRITE reg[{regNumToName(self.wa())}] = {self.wd():08x}")
                self.reg[self.wa()] = self.wd()
            except IndexError as x:
                raise IndexError(f"Register {self.wa()} is not a valid register.")


class RvCPU():
    "RISCV CPU emulator, memory is an ELFMemory instance (see load_elf)"
    def __init__(self, mem, pc = 0x80000000, quiet = False):
        # store the ELF memory in the cpu instance
        self.mem = mem

        # --------------------
        # construct the CPU architecture here (sodor 1 stage)
        # all CPU logic should appear here.
        # --------------------

        # use the pcmux to feed the correct next pc value into the pc register
        # since we haven't declared pcmux yet, we need to use a lambda to defer
        # the evaluation of the output of the pcmux until after the pcmux is
        # declared.  This is a common pattern in python.
        self.pc = PC(lambda: self.pcmux.output(), initialpc=pc)

        # store the pc value through the whole instruction (pc is updated while executing the instruction)
        self.pcval = pc

        # a gate that adds four to the pc
        self.pc_plus4 = Plus4(lambda: self.pcval)

        # the branch type is determined by func3, so this is just a mux
        # TODO Implement these branch conditions to return true/false as needed
        # signed comparisons need to be converted to python ints with tc_to_int!
        # All of these comparions are execution using the register value of both rs1 and rs2
        self.branchCondGen = mux(lambda: self.instruction.func3,
            lambda: tc_to_int(self.reg[self.instruction.rs1]) == tc_to_int(self.reg[self.instruction.rs2]), # beq  000
            lambda: tc_to_int(self.reg[self.instruction.rs1]) != tc_to_int(self.reg[self.instruction.rs2]), # bne  001
            lambda: False,                                                  # unused 010
            lambda: False,                                                  # unused 011
            lambda: tc_to_int(self.reg[self.instruction.rs1]) < tc_to_int(self.reg[self.instruction.rs2]),  # blt  100
            lambda: tc_to_int(self.reg[self.instruction.rs1]) >= tc_to_int(self.reg[self.instruction.rs2]), # bge  101
            lambda: self.reg[self.instruction.rs1] < self.reg[self.instruction.rs2],  # bltu 110
            lambda: self.reg[self.instruction.rs1] >= self.reg[self.instruction.rs2], # bgeu 111
            )

        # the branch mux selects the branch condition or the pc+4
        self.branchmux = mux(lambda: 1 if self.instruction.is_branch and self.branchCondGen.output() else 0,
            self.pc_plus4.output, # NOT taken branches go to pc + 4
            lambda: (self.pc.output() + self.instruction.sb_imm) & 0xFFFFFFFF, 	 # TODO: return the correct branch target [pc + sb_imm] for taken branches
            )

        # the mux in front of the pc register selects the next pc value
        self.pcmux = mux(lambda: self.control['pc_sel'],
            self.pc_plus4.output,
            lambda: (self.reg[self.instruction.rs1] + self.instruction.i_imm) & 0xFFFFFFFF, # TODO: jalr target = rs1 + i_imm and masked values to remain within index memory index
            self.branchmux.output,# branch target
            lambda: (self.pc.output() + self.instruction.uj_imm) & 0xFFFFFFFF, # TODO:  jump target = pc + uj_imm and masked values to remain within index memory
            )

        # the op1 and op2 muxes select the operands for the ALU
        self.op1mux = mux(lambda: self.control['op1_sel'],
            lambda: self.reg[self.instruction.rs1],     # rs1
            lambda: self.instruction.z_imm,   # imz
            lambda: self.instruction.u_imm    # imu
            )

        self.op2mux = mux(lambda: self.control['op2_sel'],
            lambda: self.reg[self.instruction.rs2],     # rs2
            lambda: self.instruction.i_imm,             # imi
            lambda: self.instruction.s_imm,             # ims
            lambda: self.pcval                          # pc
            )

        # the ALU is a mux of all the possible ALU operations
        self.alu = mux(lambda: self.control['ALU_fun'],
            lambda: None, # add / unused
            lambda: self.op1mux.output() ^ self.op2mux.output(), # xor
            lambda: self.op1mux.output(),                        # copy1
            lambda: self.op1mux.output() < self.op2mux.output(), # set less than unsigned [sltu]
            lambda: self.op1mux.output() & self.op2mux.output(), # and
            lambda: int_to_tc(tc_to_int(self.op1mux.output()) + tc_to_int(self.op2mux.output())), # add (signed)
            lambda: int_to_tc(tc_to_int(self.op1mux.output()) < tc_to_int(self.op2mux.output())), # TODO set less than [slt], convert to integers them compare before converting backk
            lambda: int_to_tc(tc_to_int(self.op1mux.output()) >> (tc_to_int(self.op2mux.output()) &0b11111)), # TODO sra convert to integers to make the bit shift with a 5 bit mask before converting back
            lambda: int_to_tc(tc_to_int(self.op1mux.output()) - tc_to_int(self.op2mux.output())), # TODO sub converting to integer to perform the subtraction befoe converting back
            lambda: ((self.op1mux.output()) >> ((self.op2mux.output() & 0b11111))), # TODO srl shift the logical values and mask the shift value
            lambda: (self.op1mux.output() << (self.op2mux.output() & 0b11111)) &0xFFFFFFFF, # TODO sll shift the logical values by the second value while masking by 5 bits and masking the result to remain within 32 bits
            lambda: self.op1mux.output() | self.op2mux.output()  # or
            )

        # the control and status register (CSR) file
        self.csrs = CsrMemory(
            lambda: self.instruction.csr,
            lambda: self.control['csr_cmd'],
            lambda: self.instruction.rs1 if self.instruction.name[-1] == 'i' else self.reg[self.instruction.rs1],
            quiet = quiet
            )   # for I type csr operations, the immediate value is in the rs1 field, else read the rs1 register.

        # construct data memory
        self.data_memory = DataMemory(mem,
            addr = lambda: self.alu.output(), 		# TODO address calculation should be handled by ALU, since it is handled by the alu we simply take the alu output value
            byte_count = lambda: self.control['mask_type'], 	# TODO byte count is the mask_type control signal, we therefore use the control with the mask_type signal
            write_enable = lambda: self.control['mem_wr'],
            write_val = lambda: self.reg[self.instruction.rs2],  # TODO what value do we write? On the sodor it states that the register value at rs2 is written
            signed = lambda: self.instruction.func3 >> 2 == 0, # unsigned operations set bit 2 of func3
            quiet = quiet
            )

        # the wb_sel mux selects the PC, result of the ALU, memory, or CSR
        # to be written back to the register file
        self.wb_selmux = mux(lambda: self.control['wb_sel'],
            self.pc_plus4.output,
            self.alu.output,
            self.data_memory.output,
            self.csrs.output
            )

        # construct registers
        self.reg = RegFile(
            en = lambda: self.control['rf_wen'],
            wa = lambda: self.instruction.rd,
            wd = self.wb_selmux.output,
            quiet = quiet
            )

        # --------------------
        # end CPU architecture
        # --------------------
        # instruction register (current executing instruction machine code value)
        self.ir = 0

        # misc options
        self.quiet = quiet

        # exit code from syscall
        self.exitcode = 0

    def exec(self):
        """
        fetch from PC and execute the instruction.
        yields the cycle number of the instruction.
        """

        for cycle in itertools.count():
            if not self.quiet:
                print("-"*60)
            # fetch the instruction from memory
            # store the current pc value as the pc register is updated in the cycle
            self.pcval = self.pc.output()

            # perform fetch
            self.ir = self.mem[self.pcval]

            # decode the instruction
            self.instruction = decode_instruction(self.ir, self.pc.output(), symbols)

            if not self.quiet:
                print(f'FETCH: [{self.pc.output():08x}] ', self.instruction)

            # get the corresponding control signals for the instruction
            self.control = control[self.instruction.name]

            if not self.quiet:
                print('DECODE:', self.control)
                print(self.instruction.dump())
                print('INPUT REGS:')
                for i in range(0,32,8):
                    print(" ".join([f"{regNumToName(i+j).rjust(3)}: {fmtreg(cpu.reg[i+j])}" for j in range(8)]))

            # check if we hit a null instruction (end of program)
            if self.instruction.val == 0:
                return
            else:

                # execute and writeback happen when we clock the registers

                # clock the PC register
                # we clock this first so that the PC is updated before any value is written to the registers
                # this is needed for rv32-ui-p-jalr test 3 that does jalr t0,t0, the pc has to be set to
                # the original register value before updating t0 with the current pc value.
                # after this PC.output gives the pc for the next instruction
                self.pc.clock()

                # clock the CSR memory to write and values to memory here
                # has to be before regfile to get CSR output into a register
                self.csrs.clock(cycle)

                # clock the regfile to write the result (if any) back to the register file
                # rv32-ui-p-jal test 2: have to write the PC value to reg before clocking in the new pc value
                self.reg.clock()

                # clock the data memory to write and values to memory here
                self.data_memory.clock()

                if not self.quiet:
                    print('RESULT REGS:')
                    for i in range(0,32,8):
                        print(" ".join([f"{regNumToName(i+j).rjust(3)}: {fmtreg(cpu.reg[i+j])}" for j in range(8)]))

                # UCB style syscall through memory
                if self.control['mem_em'] == 1 and self.control['mem_wr'] == 1 and 'tohost' in symbols:
                    # syscalls are writes to the 64 bit tohost address
                    # so we wait for the write to the second part of the address
                    if (self.alu.output() == symbols['tohost']+4):
                        if not self.quiet:
                            print('-'*30 + f'<{"syscall".center(20)}>' + '-'*30)
                        stop, returncode = self.syscall()
                        if stop == False:
                            # signal back that syscall is complete
                            self.data_memory.mem[symbols['fromhost']] = 1
                        else:
                            # end the simulation
                            self.exitcode = returncode
                            return

                # check for plain ECALLS
                if self.instruction.name == 'ecall':
                    a0 = self.reg[10] # reg.read(10) # reg 10 is a0
                    if not self.quiet:
                        print(f"ECALL({a0}): ", end="")

                    # linux style syscalls use a7 as the linux function
                    a7 = self.reg[17] # reg.read(17)
                    if a7 == 93:
                        # sys_exit
                        # riscv_test sets the low bit to indicate failure
                        # then the exit code is in the upper bits
                        # so remove the failure bit to get the actual exit code
                        self.exitcode = a0 >> 1
                        return
                    if a0 == 0:
                        print("HALT")
                        # UCB test code exists with this syscall on success
                        self.exitcode = 0
                        return
                    elif a0 == 10:
                        print("EXIT")
                        self.exitcode = 0

                        return
                    elif a0 == 1:
                        # print int
                        print(self.reg[11]) # print the value of the a1 register
                    else:
                        raise ValueError(f"Undefined ecall value {a0}")

                # yield the current instruction
                yield cycle

    def syscall(self):
        "handle a UCB style syscall through tohost memory write"
        val = self.data_memory.mem[symbols['tohost']]
        mem = self.data_memory.mem
        if val & 0b1 == 0b1:
            # exit
            if not self.quiet:
                print (f"SYSCALL: exit ({val>>1})")
            return True, val >> 1
        else:
            # val is the memory address to the "magic mem" block
            # annoyingly this is 4 x 64 bit values even on 32-bit
            # but the upper 4 bits are unused since ptr vals are only 32-bit
            which = mem[val]
            arg0 = mem[val+8]
            arg1 = mem[val+16]
            arg2 = mem[val+24]

            if which == 64:
                # putch, arg0 = 1 (?), arg1 = pointer to string data, arg2 = length
                #print (f"putch @ {arg1:08x} of len {arg2}")
                print (mem[arg1:arg1+arg2].decode("ASCII"), end = "")
            else:
                raise ValueError(f"Syscall not supported: {which}, {arg0}, {arg1:x}, {arg2}")

            return False, 0

if __name__=="__main__":
    parser = argparse.ArgumentParser(
        description=__doc__)
    parser.add_argument('elffiles', nargs="+",
        help="Binary instructions in ELF file format compiled for direct execution on the CPU.")
    parser.add_argument('--wordsize', type=int, default=4)
    parser.add_argument("-q", "--quiet",
        help="Quieter output (no extra info) [default=False]",
        action="store_true", default=False)
    parser.add_argument("-d", "--disassemble",
        help="Show disassembly of the program [default=False]",
        action="store_true", default=False)
    parser.add_argument("-t", "--test",
        help="Test mode for riscv-test suite [stops on failure, default=False]",
        action="store_true", default=False)

    args = parser.parse_args()

    # allow multiple files from the CLI
    for elffile in args.elffiles:

        if not args.quiet:
            head = '='*30 + f'<{elffile.center(20)}>' + '='*30
            print(head)

        try:
            # load the elf file and symbol table into memory
            sys_mem, symbols = load_elf(elffile, quiet = args.quiet)
        except Exception as x:
            print(f"ERR - couldn't load {elffile}.")
            raise(x)

        #print("-"*60)
        cpu = RvCPU(sys_mem, pc=symbols['_start'], quiet = args.quiet)

        for cycle in cpu.exec():
            if args.disassemble:
                print (f"{cycle:20d}: PC={fmtreg(cpu.pcval)}, IR={cpu.ir:08x}, {cpu.instruction}")
            if not args.quiet:
                print("~"*60)

        # print final instruction
        cycle += 1
        if args.disassemble:
            print (f"{cycle:20d}: PC={fmtreg(cpu.pcval)}, IR={cpu.ir:08x}, {cpu.instruction}")

        if not args.quiet:
            print("~"*60)

            # print the registers

            print("Final register values:")
            for i in range(0,32,8):
                print(" ".join([f"{regNumToName(i+j).rjust(3)}: {fmtreg(cpu.reg[i+j])}" for j in range(8)]))


        if args.test:
            if cpu.exitcode == 0:
                print(f"{elffile} PASSED")
            else:
                print(f"{elffile} FAILED on test {cpu.exitcode}")
                break
        if not args.quiet:
            print("="*len(head))
