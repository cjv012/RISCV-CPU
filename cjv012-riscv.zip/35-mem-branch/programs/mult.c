/*
 Multiply two numbers with repeated additions.
 */


#include <stdio.h>

int main(int argc, char *argv[]) {
	int a = 5;
	int b = 6;
	int c = 0;
	int i = 0;
	for (i = 0; i < b; i++) {
		c += a;
	}
	
	return c;
}