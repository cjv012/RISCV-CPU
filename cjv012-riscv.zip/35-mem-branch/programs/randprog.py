"""
generate a random sequence of arithmetic instructions
"""

import random
import subprocess
import os
import os.path
import shlex
def run(cmd, cwd=None, input=None, shell=False, timeout=90):
    try:
        result = subprocess.run(
            cmd if shell else shlex.split(cmd),
            executable = '/bin/bash' if shell else None,
            env=os.environ.copy(),
            cwd=cwd,
            input=input,
            shell=shell,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            universal_newlines=True
        )
        #return result.returncode, result.stdout.decode("utf-8", "replace").strip()
        return result.returncode, result.stdout
    except UnicodeDecodeError:
        return 255, "Couldn't decode, non-text output detected!"
def gen():

	regs = ['x%d' % i for i in range(1,16)]

	yield ("_start:")
	# init
	for reg in regs:
		yield(f"li {reg}, {random.randint(-2**11, 2**11-1)}")

	# generate random instructions
	for _i in range(256):
		
		op = random.choice(['add', 'addi', 'and', 'andi', 'or', 'ori', 'sll', 'sra', 'srl', 'srli', 'sub', 'xor', 'xori', 'li', 'not'])

		reg1 = random.choice(regs)
		reg2 = random.choice(regs)
		reg3 = random.choice(regs)

		i_imm = random.randint(-2**11, 2**11-1)

		# ensure register is valid
		if op == 'sll' or op == 'sra' or op == 'srl':
			yield (f"li {reg3}, {random.randint(0, 31)}")
			_i+=1
		elif op == 'srli':
			i_imm = random.randint(0, 31)
		
		if op == 'li':
			yield(f"li {reg1}, {i_imm}")
		elif op == 'not':
			yield(f"{op} {reg1}, {reg2}")
		elif op[-1] == 'i':
			yield(f"{op} {reg1}, {reg2}, {i_imm}")
		else:
			yield(f"{op} {reg1}, {reg2}, {reg3}")


def build(asmfile, objfile, binfile):
	r = run(f'riscv64-unknown-elf-as -march=rv32i -mabi=ilp32 -o {objfile} {asmfile}')
	if r[0] == 0:
		r = run(f'riscv64-unknown-elf-ld -static -nostdlib -m elf32lriscv -e 0x80000000 -T test.ld -o {binfile} {objfile}')
		if r[0] == 0:
			print(f'write {binfile}. success.')
		else:
			print(f'link failed ({r[0]}).')
	else:
		print(f'assemble failed ({r[0]}).')
		print(r[1])

for i in range(1, 6):
	asmfile = f'prog{i}.asm'
	objfile = f'prog{i}.o'
	binfile = f'prog{i}'

	with open(asmfile, 'w') as f:
		for inst in gen():
			f.write(inst + '\n')

	build(asmfile, objfile, binfile)

		

	