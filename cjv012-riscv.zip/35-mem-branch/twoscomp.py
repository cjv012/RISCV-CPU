def int_to_tc(n, w=32):
	"""
	Convert a python integer to two's complement representation of width w (bits)
	as a positive python integer .
	>>> int_to_tc(0)
	0
	>>> int_to_tc(1)
	1
	>>> int_to_tc(-1)
	4294967295
	"""
	# 0xffff ... ffff
	mask = (1 << w) - 1
	if 0:
		# this works in python but uses 33 bits
		return n & mask
	
	if n < 0:		
		return (~(abs(n)) & mask) + 1
	else:
		return n & mask
	
def tc_to_int(n, w=32):
	"""
	Convert a signed two's complement integer to a regular python integer.
	>>> tc_to_int(0)
	0
	>>> tc_to_int(1)
	1
	>>> tc_to_int(4294967295)
	-1
	"""
	assert n >= 0, f"n must be a positive integer got {n:08x}"
	
	# 0xffff ... ffff
	mask = (1 << w) - 1
	# check if the sign bit is set, if so 
	sign = 0b1 & (n >> (w-1))
	if sign == 0b1:
		# negative number
		return -((~n & mask) + 1)
	else:
		return n & mask
