from util import regNumToName
from csr_list import csrs
from twoscomp import tc_to_int, int_to_tc

# build a csr lookup table
csrd = [None] * 0xfff
for k,v in csrs:
    csrd[k] = v

class BadInstruction(Exception):
    pass

class InstructionBase:

    def dump(self):
        "dump all instruction details, useful for debugging"
        f = ['val', 'op', 'rd','rs1','rs2', 'func3', 'func7']
        s = ", ".join([f'{_n.rjust(11)}: {format(getattr(self, _n), "08x")}' for _n in f])
        
        f = ['i_imm', 's_imm', 'sb_imm', 'u_imm', 'uj_imm', 'z_imm']
        s += '\n' + ", ".join([f'{_n.rjust(11)}: {format(getattr(self, _n), "08x")}' for _n in f])
        f = ['is_branch', 'is_jump', 'is_jump_reg', 'is_csr']
        s += '\n' + ", ".join([f'{_n.rjust(11)}: {format(getattr(self, _n)).ljust(8)}' for _n in f])

        if self.is_csr:
            s += f'\n{"csr".rjust(10)}: {format(self.csr, "08x")} == {csrd[self.csr]}'
        return s
    
    def __init__(self, val: int, pc : int = 0, symbols: dict = {}):
        self.pc = pc
        self.symbols = symbols
        self.val = val
        self.op = val & 0x7f

        # common fields decoded for all instructions, even if not used
        self.rd = 0x1f & (self.val >> 7)
        self.rs1 = 0x1f & (self.val >> 15)
        self.rs2 = 0x1f & (self.val >> 20)
        self.func3 = (self.val >> 12) & 0x7 
        self.func7 = 0x7f & (self.val >> 25)
        
        self.csr = 0xfff & (self.val >> 20)
        
        # decode all possible immediate values
        #self.i_imm = tc_to_int(0xfff & (self.val >> 20), 12)

        # this creates the 32 bit twos complement representation of the 12 bit immediate value
        self.i_imm = int_to_tc(tc_to_int(0xfff & (self.val >> 20), 12))
            
        self.s_imm = int_to_tc(tc_to_int(0xfff & (
                    (0x1f & (self.val >> 7)) |
                    ((0x7f & (self.val >> 25)) << 5)
                ), 12))
        self.sb_imm = int_to_tc(tc_to_int(
            0x1fff & (
                ((0xf  & (self.val >> 8)) << 1)   |
                ((0x3f & (self.val >> 25)) << 5 ) |
                ((0x1  & (self.val >> 7)) << 11 ) |
                ((0x80000000 & self.val) >> 19)
            ), 13))
        self.u_imm = int_to_tc(tc_to_int(0xfffff000 & self.val, 32))
        self.uj_imm = int_to_tc(tc_to_int(0x1fffff & 
            (
                ((0x3ff & (self.val >> 21)) << 1) |
                ((0x1 & (self.val >> 20)) << 11) |
                ((0xff & (self.val >> 12)) << 12) |
                ((0x1 & (self.val >> 31)) << 20)
            ), 21))
        # special case for CSR instructions, immediate val is stored in rs1's place.
        self.z_imm = int_to_tc(tc_to_int(0x1f & (self.val >> 15), 5))
        # instruction name
        self.name = "" # to be filled in later by a decoder     
        self.asm = None # to be filled in later by a decoder   
        
        # extra flags for special instruction types
        self.is_branch = False
        self.is_jump = False
        self.is_jump_reg = False
        self.is_csr = False

    def __str__(self) -> str:
        # stub... replace with your code
        # given the decoded fields, format the instruction as a string
        return  self.asm


class LoadStoreBranchInstruction(InstructionBase):
    "I type, S and SB type instructions here!"

    def __init__(self, val: int, *args):
        super().__init__(val, *args)

        if 0b11 & (self.op >> 5) == 0b00:
            # LOAD
            self.name = ['lb',
                         'lh',
                         'lw',
                         'ld',
                         'lbu',                         
                         'lhu',
                         'lwu'][self.func3]
            self.asm = f"{self.name}\t{regNumToName(self.rd)},{self.i_imm}({regNumToName(self.rs1)})"

        elif 0b11 & (self.op >> 5) == 0b01:
            #STORE
            self.name = [
                'sb',
                'sh',
                'sw'
            ][self.func3]
            self.asm = f"{self.name}\t{regNumToName(self.rs2)},{self.s_imm}({regNumToName(self.rs1)})"

        elif 0b11 & (self.op >> 5) == 0b10:
            #MADD
            self.name = 'madd'
            raise NotImplementedError()
        elif 0b11 & (self.op >> 5) == 0b11:
            #BRANCH
            self.is_branch = True
            self.name = [
                'beq', #000
                'bne',
                '---', #010 ?
                '---', #011 ?
                'blt', #100
                'bge', #101
                'bltu', #110
                'bgeu', #111
            ][self.func3]
            
            # compute branch target for debug printing only
            target = self.pc + tc_to_int(self.sb_imm)

            if self.name == '---':
                raise BadInstruction()
            elif self.rs1 == 0:
                # pseudo instruction   
                self.asm = f"{self.name}z\t{regNumToName(self.rs2)},pc{tc_to_int(self.sb_imm):+3d}\t({target:x})"
            elif self.rs2 == 0:
                # pseudo instruction
                self.asm = f"{self.name}z\t{regNumToName(self.rs1)},pc{tc_to_int(self.sb_imm):+3d}\t({target:x})"
            else:
                self.asm = f"{self.name}\t{regNumToName(self.rs1)},{regNumToName(self.rs2)},pc{tc_to_int(self.sb_imm):+3d}\t({target:x})"

            if target in self.symbols:
                self.asm += f' <{self.symbols[target]}>'                
        else:
            raise BadInstruction()

class JalrInstruction(InstructionBase):
    def __init__(self, val: int, *args):
        super().__init__(val, *args)
        #JALR instruction here
        if self.op == 0b1100111 and self.func3 == 0b000:
            self.is_jump_reg = True
            self.name = 'jalr'
            if self.rd == 0:
                if self.rs1 == 1 and self.i_imm == 0:
                    self.asm = 'ret'
                else:
                    self.asm = f'jr\t{regNumToName(self.rs1)}'
                
            else:
                self.asm = f'{self.name}\t{regNumToName(self.rd)},{regNumToName(self.rs1)}'
            if self.i_imm > 0:
                self.asm += f'\t({self.i_imm:x})'
        else:
            raise NotImplementedError() 
        
class MemJalInstruction(InstructionBase):
    def __init__(self, val: int, *args):
        super().__init__(val, *args)

        if 0b11 & (self.op >> 5) == 0b11:
            # jumps
            self.is_jump = True
            self.name = 'jal'
            if self.rd == 0:
                # j pseudo instruction
                self.asm = f"j\t{(self.pc + self.uj_imm):8x}"
            else:                
                self.asm = f"{self.name}\t{regNumToName(self.rd)},{(self.pc + self.uj_imm):8x}"
            if self.pc + self.uj_imm in self.symbols:
                self.asm += f'\t<{self.symbols[self.pc + self.uj_imm]}>'
        elif self.op == 0b0001111 and self.func3 == 0b000:
            # not fully implemented/decoded
            self.name = 'fence'
            self.asm = 'fence'
        else:
            print("MISCMEM:\n" + self.dump())
            raise NotImplementedError()
        
class OpOpImmSystemInstruction(InstructionBase):
    def __init__(self, val: int, *args):
        super().__init__(val, *args)
        
        if 0b11 & (self.op >> 5) == 0b00:          
            self.name = [
                'addi',# 0 
                'slli',
                'slti',
                'sltiu',
                'xori', # 4
                'srli',
                'ori',
                'andi', # 7
            ][self.func3]

            self.asm = f"{self.name}\t{regNumToName(self.rd)},{regNumToName(self.rs1)},{tc_to_int(self.i_imm)}"
            
            # mask shift amounts from immediate
            #if self.name in ['slli', 'srli']:
                #self.shamt = 0x1f & (self.val >> 20)
            #    self.i_imm = 0x1f & (self.val >> 20)

            # special cases
            if self.name == 'addi' and self.rs1 == 0b0:
                # cosmetic, psuedo op translation                
                self.asm = f"li\t{regNumToName(self.rd)},{tc_to_int(self.i_imm)}"

            if self.func3 == 0b101:                
                if self.func7 == 0b0100000:
                    self.name = 'srai'
                    self.asm = f"{self.name}\t{regNumToName(self.rd)},{regNumToName(self.rs1)},0x{self.i_imm:x}"
                else:
                    # shift immediate are printed in hex
                    self.asm = f"{self.name}\t{regNumToName(self.rd)},{regNumToName(self.rs1)},0x{self.i_imm:x}"
                
            if self.func3 == 0b001:                
                self.asm = f"{self.name}\t{regNumToName(self.rd)},{regNumToName(self.rs1)},0x{self.i_imm:x}"

        elif 0b11 & (self.op >> 5) == 0b01:
            # opcodes: 01100xx
            self.name = [
                'add',# 0  (also sub)
                'sll',
                'slt',
                'sltu',
                'xor', # 4
                'srl', # and sra
                'or',
                'and', # 7
            ][self.func3]
            if self.func3 == 5 and self.func7 == 0b0100000:
                self.name = 'sra'
            if self.func3 == 0 and self.func7 == 0b0100000:
                self.name = 'sub'
            
            # mask shift amounts from immediate
            #if self.name[0] == 's':
                #self.shamt = 0x1f & (self.val >> 20)
            #    self.i_imm = 0x1f & (self.val >> 20)

            self.asm = f"{self.name}\t{regNumToName(self.rd)},{regNumToName(self.rs1)},{regNumToName(self.rs2)}"
        elif 0b11 & (self.op >> 5) == 0b10:
            self.name = 'op-fp'
            raise NotImplementedError() 
        elif 0b11 & (self.op >> 5) == 0b11:
                
            if (self.val >> 7) == 0:
                self.name = 'ecall'
                self.asm = self.name
            elif (self.val >> 7) == 0b0000000000010000000000000:
                self.name = 'ebreak'
                self.asm = self.name
            else:                                          
                # system opcodes are messy
                if self.csr == 0 and self.rs1 == 0 and self.func3 == 0 and self.rd == 0:
                    self.name = 'ecall'
                    self.asm = 'ecall'                    
                elif self.csr == 1 and self.rs1 == 0 and self.func3 == 0 and self.rd == 0:
                    self.name = 'ebreak' 
                    self.asm = 'ebreak'
                elif self.func3 == 0 and self.rs1 == 0 and self.rd == 0:                    
                    # Uret/Sret/Hret/Mret
                    if self.i_imm == 0b000000000010:
                        self.name, self.asm ='uret', 'uret'
                    elif self.i_imm == 0b000100000010:
                        self.name, self.asm ='sret', 'sret'
                    elif self.i_imm == 0b01000000010:
                        self.name, self.asm ='hret', 'hret'
                    elif self.i_imm == 0b001100000010:
                        self.name, self.asm ='mret', 'mret'
                    else:
                        raise ValueError("Unsupported instruction")
                else:
                    self.name = [
                        '---', # ecall or ebreak
                        'csrrw',
                        'csrrs',
                        'csrrc',
                        '---' # 4
                        'csrrwi',
                        'csrrsi',
                        'csrrci'
                    ][self.func3]                          
                    pname = self.name

                    self.is_csr = True
                    
                    # pseudo name generation
                    if self.rd == 0:
                        # drop inner r
                        pname = self.name[0:3] + self.name[4:]     
                    asm = []
                    # not pseudo op
                    if self.rd != 0:                    
                        asm += [regNumToName(self.rd)]

                    asm += [csrd[self.csr]]
                    
                    if self.name[-1] == 'i':
                        # rs1 is used as the immediate value
                        asm += [str(self.rs1)]
                    else:
                        if self.rs1 != 0:
                            asm += [regNumToName(self.rs1)]
                    self.asm = f"{pname}\t" + ",".join(asm)                                      
        else:
            raise BadInstruction()
    
class AuipcLuiInstruction(InstructionBase):
    def __init__(self, val: int, *args):
        super().__init__(val, *args)
        if self.op == 0b0110111:
            self.name = 'lui'
        elif self.op == 0b0010111:
            self.name = 'auipc'
        else:
            raise BadInstruction()
        # objdump output doesn't show trailing 12-bit of zeros for display
        # and it shows the unsigned value
        self.asm = f"{self.name}\t{regNumToName(self.rd)},0x{(0xfffff000 & self.val)>>12:05x}"


def decode_instruction(val, *args):
    "use the most specific instruction class to decode the instruction"
    # organized by bits 4:2 of instruction
    # https://riscv.org/wp-content/uploads/2017/05/riscv-spec-v2.2.pdf
    # page 103
    return [
        LoadStoreBranchInstruction, # 000 LOAD_STORE_BRANCH
        JalrInstruction,			# 001 LOADFP_STOREFP_JALR
        None,						# 010 CUSTOM0
        MemJalInstruction,			# 011 MISCMEM_JAL
        OpOpImmSystemInstruction,   # 100 OP_OPIMM_SYSTEM
        AuipcLuiInstruction,		# 101 AUIPC_LUI
        None,               		# 110 OP32_OPIMM32
        None						# 111 CUSTOM1
    ][(val >> 2) & 0b111](val, *args)

    