
# define the basic gates: not, and, or, xor
class gate:
	"Base class for all gates"
	def __init__(self, quiet = True):
		self.logic = None
		self.quiet = quiet
	def output(self):
		"""
		Returns the current value of the output.
		Gates with multiple outputs could return a tuple or define new methods.
		"""
		if self.logic is None:
			raise NotImplementedError("output() not implemented")
		return self.logic.output()
	def clock(self):
		"clocks the gate, updating the internal state (if any)"
		pass
class notgate(gate):
	def __init__(self, a):
		"a is a function that returns the current value of the input"
		self.a = a
	def output(self):
		# note that a is a function that needs to be executed
		# to get the current value
		return not self.a()
class andgate(gate):
	def __init__(self, a, b):
		"a and b are functions that return the current values of the inputs"
		self.a = a
		self.b = b
	def output(self):
		# note that a and b are functions that need to be executed
		# to get the current values
		return self.a() & self.b()
class orgate(gate):
	def __init__(self, a, b):
		"a and b are functions that return the current values of the inputs"
		self.a = a
		self.b = b
	def output(self):
		# note that a and b are functions that need to be executed
		# to get the current values
		return self.a() | self.b()

# now use the basic gates to define the xor gate
class xorgate(gate):
	def __init__(self, a, b):
		"a and b are functions that return the current values of the inputs"
		self.a = a
		self.b = b
		# instantiate the logic once, then invoke it in output()
		self.logic = orgate(
				andgate(self.a, notgate(self.b).output).output, 
				andgate(notgate(self.a).output, self.b).output
				)